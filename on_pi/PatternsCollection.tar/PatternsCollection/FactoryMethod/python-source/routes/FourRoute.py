from routes import Route


class FourRoute(Route):
    def connect(self) -> str:
        return 'Connnected via 4g'