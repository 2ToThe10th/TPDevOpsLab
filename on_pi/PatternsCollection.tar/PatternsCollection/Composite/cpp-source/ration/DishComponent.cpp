//
// Created by Pavel Akhtyamov on 2019-03-26.
//

#include "../include/DishComponent.h"


